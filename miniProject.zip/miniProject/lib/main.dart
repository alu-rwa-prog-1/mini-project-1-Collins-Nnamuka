import 'package:flutter/material.dart';
import 'horilist.dart';
import 'products.dart';
import 'bottomnav.dart';

// import 'home.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage(),
  ));
}

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: new AppBar(
        backgroundColor: Colors.black,
        title: Text("DeWave Motos"),
        actions: <Widget>[
          new IconButton(
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
              onPressed: () {}),
          new IconButton(
              icon: Icon(
                Icons.settings,
                color: Colors.white,
              ),
              onPressed: () {}),
        ],
      ),
      drawer: new Drawer(
        child: new ListView(children: <Widget>[
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Car Rental"),
                leading: Icon(Icons.car_rental, color: Colors.black),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Car Repair"),
                leading: Icon(Icons.car_repair, color: Colors.black),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("My Account"),
                leading: Icon(Icons.person, color: Colors.black),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Contact Us"),
                leading: Icon(Icons.contact_page, color: Colors.black),
              )),
          InkWell(
              onTap: () {},
              child: ListTile(
                title: Text("Settings"),
                leading: Icon(Icons.settings, color: Colors.black),
              )),
        ]),
      ),
      body: new ListView(
        children: <Widget>[
          new Padding(
            //Padding my widget and adding my horizontal view
            padding: const EdgeInsets.all(9.0),
            child: new Text('Categories'),
          ),
          //Importing horizontal list view
          HorizontalList(),
          new Padding(
            //Padding my widget and adding my horizontal view
            padding: const EdgeInsets.all(14.0),
            child: new Text('Latest Release'),
          ),
          //Grid View
          Container(
            height: 1000.0,
            child: Products(),
          ),
        ],
      ),
      bottomNavigationBar: MyBottomNavBar(),
    );
  }
}
