import 'package:flutter/material.dart';

class Products extends StatefulWidget {
  @override
  _ProductsState createState() => _ProductsState();
}

class _ProductsState extends State<Products> {
  var product_list = [
    {
      "name": "Buggati Chiron",
      "picture": "images/chiron.jpg",
      "old_price": 100,
      "price": 780,
    },
    {
      "name": "Volkswagen Golf",
      "picture": "images/golf.jpg",
      "old_price": 800,
      "price": 78,
    },
    {
      "name": "Benz Mclaren",
      "picture": "images/mcleren.jpg",
      "old_price": 120,
      "price": 890,
    },
    {
      "name": "Alfa Romeo 300",
      "picture": "images/romeo.jpg",
      "old_price": 670,
      "price": 748,
    },
    {
      "name": "Bentley",
      "picture": "images/bentley.jpg",
      "old_price": 7800,
      "price": 4590,
    },
    {
      "name": "I-VTEC",
      "picture": "images/bmw.jpg",
      "old_price": 7800,
      "price": 4590,
    },
  ];
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        itemCount: product_list.length,
        gridDelegate:
            new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
        itemBuilder: (BuildContext context, int index) {
          return Single_Product(
            product_name: product_list[index]['name'],
            product_image: product_list[index]['picture'],
            product_oldprice: product_list[index]['old_price'],
            product_price: product_list[index]['price'],
          );
        });
  }
}

class Single_Product extends StatelessWidget {
  final product_name;
  final product_image;
  final product_oldprice;
  final product_price;

  Single_Product({
    this.product_name,
    this.product_image,
    this.product_oldprice,
    this.product_price,
  });
  @override
  Widget build(BuildContext context) {
    return Card(
      child: Hero(
        tag: product_name,
        child: Material(
          child: InkWell(
            onTap: () {},
            child: GridTile(
              footer: Container(
                color: Colors.white,
                child: ListTile(
                  leading: Text(
                    product_name,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  title: Text(
                    "\$$product_price",
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.w800),
                  ),
                  subtitle: Text(
                    "\$$product_oldprice",
                    style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.w800,
                        decoration: TextDecoration.lineThrough),
                  ),
                ),
              ),
              child: Image.asset(
                product_image,
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
