import 'package:flutter/material.dart';

class HorizontalList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 100.0,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: <Widget>[
          Category(
            image_location: 'images/Lambo1.jpg',
            image_caption: 'Lambo 2019',
          ),
          Category(
            image_location: 'images/Supra1.jpg',
            image_caption: 'Toyota Supra',
          ),
          Category(
            image_location: 'images/Audi1.jpg',
            image_caption: 'Audi R8',
          ),
          Category(
            image_location: 'images/AstonMartin1.jpg',
            image_caption: 'Aston Martin Evo',
          ),
          Category(
            image_location: 'images/Benz1.jpg',
            image_caption: 'Merc 2020',
          ),
          Category(
            image_location: 'images/Benz2.jpg',
            image_caption: 'Merc AMG',
          ),
        ],
      ),
    );
  }
}

class Category extends StatelessWidget {
  final String image_location;
  final String image_caption;

  Category({
    this.image_location,
    this.image_caption,
  });
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(2.0),
      child: InkWell(
        onTap: () {},
        child: Container(
          width: 150.0,
          child: ListTile(
            title: Image.asset(
              image_location,
              width: 100.0,
              height: 100.0,
            ),
            subtitle: Container(
              alignment: Alignment.topCenter,
              child: Text(image_caption),
            ),
          ),
        ),
      ),
    );
  }
}
